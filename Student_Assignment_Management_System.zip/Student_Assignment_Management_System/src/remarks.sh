#!/usr/bin/env bash
# ==============================================================================
# STUDENT ASSIGNMENT SUBMISSION & PLAGIARISM MONITORING SYSTEM
# File: src/remarks.sh
# Purpose: Modules 8 & 9 - Faculty Remarks, Academic Grading, Plagiarism Review
# Compatibility: Ubuntu / Linux / GitHub Codespaces / POSIX Bash
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/utils.sh"

# ------------------------------------------------------------------------------
# 1. Faculty Plagiarism Review (Module 8)
# ------------------------------------------------------------------------------
plagiarism_review() {
    print_header "FACULTY PLAGIARISM & INTEGRITY REVIEW"

    echo -e "${COLOR_YELLOW}Academic Advisory:${COLOR_RESET}"
    echo "  Cryptographic SHA-256 detection identifies bitwise identical submissions."
    echo "  It does not detect paraphrasing, commented changes, or renamed variables."
    echo "  Manual faculty inspection of source code structure is essential."
    print_divider

    # List submissions currently tagged as Duplicate Suspected or Unverified
    local flagged
    flagged=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | grep -E "Duplicate Suspected|Unverified|Under Review" || true)

    if [[ -z "$flagged" ]]; then
        print_info "No pending submissions currently flagged for review."
        read -r -p "Do you want to review another specific Submission ID? (y/n): " ans
        if [[ "$ans" != "y" && "$ans" != "Y" ]]; then
            pause
            return 0
        fi
    else
        echo -e "${COLOR_RED}Flagged Submissions Pending Evaluation:${COLOR_RESET}\n"
        echo "$flagged" | awk -F'|' '
        BEGIN {
            printf "+----------+---------------+---------------+---------+---------------------+---------------------+\n"
            printf "| %-8s | %-13s | %-13s | %-7s | %-19s | %-19s |\n", "SUB ID", "ROLL NO", "ASSIGNMENT", "VERSION", "TIMESTAMP", "STATUS"
            printf "+----------+---------------+---------------+---------+---------------------+---------------------+\n"
        }
        {
            printf "| %-8s | %-13s | %-13s | %-7s | %-19s | %-19.19s |\n", $1, $2, $3, $7, $5, $8
        }
        END {
            printf "+----------+---------------+---------------+---------+---------------------+---------------------+\n"
        }
        '
    fi

    echo ""
    read -r -p "Enter Submission ID to review: " sub_id
    sub_id=$(sanitize_string "$sub_id")

    local record
    record=$(grep "^${sub_id}|" "${SUBMISSIONS_DB}" 2>/dev/null || true)

    if [[ -z "$record" ]]; then
        print_error "Submission ID '${sub_id}' not found."
        pause
        return 1
    fi

    local roll_no asgn_id file_path cur_status cur_hash
    roll_no=$(echo "$record" | cut -d'|' -f2)
    asgn_id=$(echo "$record" | cut -d'|' -f3)
    file_path=$(echo "$record" | cut -d'|' -f4)
    cur_hash=$(echo "$record" | cut -d'|' -f6)
    cur_status=$(echo "$record" | cut -d'|' -f8)

    local student_name
    student_name=$(grep "^${roll_no}|" "${STUDENTS_DB}" 2>/dev/null | cut -d'|' -f2)
    student_name="${student_name:-Unknown}"

    print_section "Reviewing Submission: ${sub_id}"
    echo "  Student:        ${student_name} (${roll_no})"
    echo "  Assignment:     ${asgn_id}"
    echo "  Current Status: ${cur_status}"
    echo "  Stored File:    ${file_path}"
    echo "  SHA-256 Hash:   ${cur_hash}"

    # Offer to preview file if exists
    if [[ -f "$file_path" ]]; then
        echo ""
        read -r -p "Preview first 15 lines of submitted code? (y/n): " prev_ans
        if [[ "$prev_ans" == "y" || "$prev_ans" == "Y" ]]; then
            echo -e "${COLOR_CYAN}--- Begin File Preview ---${COLOR_RESET}"
            head -n 15 "$file_path"
            echo -e "${COLOR_CYAN}--- End Preview ---${COLOR_RESET}"
        fi
    fi

    print_divider
    echo "Select Plagiarism Determination:"
    echo "  1) Cleared               (No intentional misconduct, legitimate coincidence or template)"
    echo "  2) Suspected             (High likelihood of unauthorized copying; escalate to committee)"
    echo "  3) Needs Further Review  (Inconclusive; requires student interview or oral defense)"

    read -r -p "Enter choice [1-3]: " pl_choice
    local review_status="Needs Further Review"
    local new_sub_status="Under Review"
    case "$pl_choice" in
        1)
            review_status="Cleared"
            new_sub_status="Reviewed"
            ;;
        2)
            review_status="Suspected"
            new_sub_status="Duplicate Suspected"
            ;;
        3)
            review_status="Needs Further Review"
            new_sub_status="Under Review"
            ;;
        *)
            print_warning "Invalid selection. Defaulting to 'Needs Further Review'."
            ;;
    esac

    read -r -p "Enter Evaluating Faculty Name: " faculty_name
    faculty_name=$(sanitize_string "$faculty_name")
    faculty_name="${faculty_name:-Faculty Reviewer}"

    read -r -p "Enter Detailed Academic Comments/Rationale: " comments
    comments=$(sanitize_string "$comments")
    comments="${comments:-No detailed comments provided.}"

    local review_date
    review_date=$(get_current_timestamp)

    # Generate unique Review ID (e.g. REV-1001)
    local last_rev
    last_rev=$(tail -n +2 "${REVIEWS_DB}" 2>/dev/null | awk -F'|' '$1 ~ /^REV-[0-9]+/ { gsub("REV-", "", $1); if ($1 > max) max = $1 } END { print (max ? max : 1000) }')
    local new_rev=$((last_rev + 1))
    local rev_id="REV-${new_rev}"

    # Default grade and acceptance status for plagiarism review
    local grade="Pending"
    local accepted="Under Review"
    if [[ "$review_status" == "Cleared" ]]; then
        accepted="Accepted"
    elif [[ "$review_status" == "Suspected" ]]; then
        accepted="Resubmit Required"
        grade="F"
    fi

    # Append to reviews database
    echo "${rev_id}|${sub_id}|${roll_no}|${asgn_id}|${faculty_name}|${review_status}|${grade}|${accepted}|${comments}|${review_date}" >> "${REVIEWS_DB}"

    # Update submission status in submissions.db
    local tmp_sub
    tmp_sub=$(mktemp "${DATA_DIR}/sub_rev_tmp.XXXXXX")
    awk -F'|' -v target="$sub_id" -v n_status="$new_sub_status" '
        $1 == target {
            $8 = n_status
            OFS = "|"
            print $1,$2,$3,$4,$5,$6,$7,$8,$9
            next
        }
        { print $0 }
    ' "${SUBMISSIONS_DB}" > "$tmp_sub" && mv "$tmp_sub" "${SUBMISSIONS_DB}"

    print_success "Review recorded under [${rev_id}]. Submission status updated to '${new_sub_status}'."
    pause
}

# ------------------------------------------------------------------------------
# 2. Add / Edit Faculty Remarks & Grade (Module 9)
# ------------------------------------------------------------------------------
add_faculty_remarks() {
    print_header "FACULTY REMARKS, GRADING & EVALUATION"

    read -r -p "Enter Submission ID (e.g. SUB-1001): " sub_id
    sub_id=$(sanitize_string "$sub_id")

    local record
    record=$(grep "^${sub_id}|" "${SUBMISSIONS_DB}" 2>/dev/null || true)

    if [[ -z "$record" ]]; then
        print_error "Submission ID '${sub_id}' not found."
        pause
        return 1
    fi

    local roll_no asgn_id
    roll_no=$(echo "$record" | cut -d'|' -f2)
    asgn_id=$(echo "$record" | cut -d'|' -f3)

    local student_name
    student_name=$(grep "^${roll_no}|" "${STUDENTS_DB}" 2>/dev/null | cut -d'|' -f2)
    student_name="${student_name:-Unknown}"

    # Check for existing review
    local existing_rev
    existing_rev=$(grep "|${sub_id}|" "${REVIEWS_DB}" 2>/dev/null | tail -n 1 || true)

    local cur_faculty="Faculty Evaluator"
    local cur_rev_status="Cleared"
    local cur_grade="A"
    local cur_accepted="Accepted"
    local cur_remarks="Good work."

    if [[ -n "$existing_rev" ]]; then
        cur_faculty=$(echo "$existing_rev" | cut -d'|' -f5)
        cur_rev_status=$(echo "$existing_rev" | cut -d'|' -f6)
        cur_grade=$(echo "$existing_rev" | cut -d'|' -f7)
        cur_accepted=$(echo "$existing_rev" | cut -d'|' -f8)
        cur_remarks=$(echo "$existing_rev" | cut -d'|' -f9)
        print_info "Existing evaluation record found. You are updating this record."
    fi

    echo -e "${COLOR_YELLOW}Evaluation for Student: ${student_name} (${roll_no}) | Assignment: ${asgn_id}${COLOR_RESET}"
    print_divider

    read -r -p "Faculty Evaluator Name [${cur_faculty}]: " in_fac
    in_fac=$(sanitize_string "$in_fac")
    faculty_name="${in_fac:-$cur_faculty}"

    echo "Select Academic Grade (e.g., A+, A, A-, B+, B, C, F):"
    read -r -p "Grade [${cur_grade}]: " in_grade
    in_grade=$(sanitize_string "$in_grade")
    grade="${in_grade:-$cur_grade}"

    echo "Select Final Submission Outcome:"
    echo "  1) Accepted"
    echo "  2) Resubmit Required"
    read -r -p "Choice (1 or 2) [Current: ${cur_accepted}]: " out_choice
    case "$out_choice" in
        1) accepted="Accepted" ;;
        2) accepted="Resubmit Required" ;;
        *) accepted="${cur_accepted}" ;;
    esac

    read -r -p "Feedback / Remarks [${cur_remarks}]: " in_rem
    in_rem=$(sanitize_string "$in_rem")
    remarks="${in_rem:-$cur_remarks}"

    local rev_date
    rev_date=$(get_current_timestamp)

    if [[ -n "$existing_rev" ]]; then
        local rev_id
        rev_id=$(echo "$existing_rev" | cut -d'|' -f1)
        local updated_rev="${rev_id}|${sub_id}|${roll_no}|${asgn_id}|${faculty_name}|${cur_rev_status}|${grade}|${accepted}|${remarks}|${rev_date}"

        local tmp_rev
        tmp_rev=$(mktemp "${DATA_DIR}/rev_tmp.XXXXXX")
        awk -F'|' -v target="$rev_id" -v rep="$updated_rev" '
            $1 == target { print rep; next }
            { print $0 }
        ' "${REVIEWS_DB}" > "$tmp_rev" && mv "$tmp_rev" "${REVIEWS_DB}"

        print_success "Review record [${rev_id}] successfully updated."
    else
        local last_rev
        last_rev=$(tail -n +2 "${REVIEWS_DB}" 2>/dev/null | awk -F'|' '$1 ~ /^REV-[0-9]+/ { gsub("REV-", "", $1); if ($1 > max) max = $1 } END { print (max ? max : 1000) }')
        local new_rev=$((last_rev + 1))
        local rev_id="REV-${new_rev}"

        echo "${rev_id}|${sub_id}|${roll_no}|${asgn_id}|${faculty_name}|Cleared|${grade}|${accepted}|${remarks}|${rev_date}" >> "${REVIEWS_DB}"
        print_success "New review record [${rev_id}] created."
    fi

    # Update status in submissions.db to Reviewed or Resubmit Required
    local final_sub_st="Reviewed"
    if [[ "$accepted" == "Resubmit Required" ]]; then
        final_sub_st="Resubmit Required"
    fi

    local tmp_sub
    tmp_sub=$(mktemp "${DATA_DIR}/sub_rem_tmp.XXXXXX")
    awk -F'|' -v target="$sub_id" -v n_status="$final_sub_st" '
        $1 == target {
            $8 = n_status
            OFS = "|"
            print $1,$2,$3,$4,$5,$6,$7,$8,$9
            next
        }
        { print $0 }
    ' "${SUBMISSIONS_DB}" > "$tmp_sub" && mv "$tmp_sub" "${SUBMISSIONS_DB}"

    print_info "Submission [${sub_id}] status marked as '${final_sub_st}'."
    pause
}
