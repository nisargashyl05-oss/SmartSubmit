#!/usr/bin/env bash
# ==============================================================================
# STUDENT ASSIGNMENT SUBMISSION & PLAGIARISM MONITORING SYSTEM
# File: src/reports.sh
# Purpose: Modules 5 & 10 - Reporting, Analytics, Overdue Detection, CSV/TXT Exports
# Compatibility: Ubuntu / Linux / GitHub Codespaces / POSIX Bash
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/utils.sh"

# ------------------------------------------------------------------------------
# 1. Check Missing / Overdue Submissions (Module 5)
# ------------------------------------------------------------------------------
check_missing_submissions() {
    print_header "OVERDUE & MISSING SUBMISSIONS MONITOR"

    if [[ ! -s "${ASSIGNMENTS_DB}" ]] || [[ $(wc -l < "${ASSIGNMENTS_DB}") -le 1 ]]; then
        print_warning "No assignments registered in database."
        pause
        return 0
    fi

    read -r -p "Enter Assignment ID to inspect (or press Enter for ALL assignments): " target_asgn
    target_asgn=$(sanitize_string "$target_asgn")

    local now_epoch
    now_epoch=$(date +%s)

    local found_any=false

    # Iterate through assignments
    while IFS='|' read -r asgn_id asgn_title asgn_subj asgn_ddl asgn_created; do
        [[ -z "$asgn_id" || "$asgn_id" == "ASSIGNMENT_ID" ]] && continue
        if [[ -n "$target_asgn" && "$asgn_id" != "$target_asgn" ]]; then
            continue
        fi

        local ddl_epoch
        ddl_epoch=$(to_epoch_seconds "$asgn_ddl")
        local is_past=false
        if (( ddl_epoch > 0 && now_epoch > ddl_epoch )); then
            is_past=true
        fi

        echo -e "\n${COLOR_BOLD}${COLOR_BLUE}Assignment: ${asgn_id} - ${asgn_title} (${asgn_subj})${COLOR_RESET}"
        echo "Deadline: ${asgn_ddl} $([[ "$is_past" == true ]] && echo -e "${COLOR_RED}[EXPIRED]${COLOR_RESET}" || echo -e "${COLOR_GREEN}[OPEN]${COLOR_RESET}")"
        print_divider

        # Find registered students who haven't submitted for this assignment
        local missing_list
        missing_list=$(tail -n +2 "${STUDENTS_DB}" | while IFS='|' read -r roll name dept email reg; do
            if ! grep -q "|${roll}|${asgn_id}|" "${SUBMISSIONS_DB}" 2>/dev/null; then
                echo "${roll}|${name}|${dept}|${email}"
            fi
        done)

        if [[ -z "$missing_list" ]]; then
            print_success "All registered students have submitted for Assignment ${asgn_id}."
        else
            found_any=true
            printf "+---------------+---------------------------+----------------------+---------------------------+\n"
            printf "| %-13s | %-25s | %-20s | %-25s |\n", "ROLL NO", "STUDENT NAME", "DEPARTMENT", "EMAIL ADDRESS"
            printf "+---------------+---------------------------+----------------------+---------------------------+\n"
            while IFS='|' read -r m_roll m_name m_dept m_email; do
                printf "| %-13s | %-25.25s | %-20.20s | %-25.25s |\n", "$m_roll", "$m_name", "$m_dept", "$m_email"
            done <<< "$missing_list"
            printf "+---------------+---------------------------+----------------------+---------------------------+\n"
            local miss_count
            miss_count=$(echo "$missing_list" | wc -l)
            echo -e "${COLOR_YELLOW}Total Missing / Not Submitted: ${miss_count}${COLOR_RESET}"
        fi
    done < "${ASSIGNMENTS_DB}"

    pause
}

# ------------------------------------------------------------------------------
# 2. Check Late Submissions (Module 5)
# ------------------------------------------------------------------------------
check_late_submissions() {
    print_header "LATE SUBMISSIONS TRACKING"

    local late_records
    late_records=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | awk -F'|' '$9 == "YES" || $8 == "Late"' || true)

    if [[ -z "$late_records" ]]; then
        print_success "No late submissions recorded. All assignments were submitted on-time!"
        pause
        return 0
    fi

    echo -e "${COLOR_RED}Late Submissions Detected:${COLOR_RESET}\n"
    printf "+----------+---------------+---------------+---------+---------------------+---------------------+------+\n"
    printf "| %-8s | %-13s | %-13s | %-7s | %-19s | %-19s | %-4s |\n", "SUB ID", "ROLL NO", "ASSIGNMENT", "VERSION", "TIMESTAMP", "STATUS", "LATE"
    printf "+----------+---------------+---------------+---------+---------------------+---------------------+------+\n"

    echo "$late_records" | while IFS='|' read -r sub roll asgn path ts hash ver st late; do
        printf "| %-8s | %-13s | %-13s | %-7s | %-19s | %-19.19s | %-4s |\n", "$sub", "$roll", "$asgn", "$ver", "$ts", "$st", "$late"
    done
    printf "+----------+---------------+---------------+---------+---------------------+---------------------+------+\n"

    local total_late
    total_late=$(echo "$late_records" | wc -l)
    echo -e "Total Late Submissions: ${total_late}"
    pause
}

# ------------------------------------------------------------------------------
# 3. View Dashboard Statistics (Menu Option 18)
# ------------------------------------------------------------------------------
view_dashboard_statistics() {
    print_header "STUDENT ASSIGNMENT SYSTEM - DASHBOARD OVERVIEW"

    local total_students total_assignments total_subs
    total_students=$(tail -n +2 "${STUDENTS_DB}" 2>/dev/null | grep -c . || echo 0)
    total_assignments=$(tail -n +2 "${ASSIGNMENTS_DB}" 2>/dev/null | grep -c . || echo 0)
    total_subs=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | grep -c . || echo 0)

    local count_ontime count_late count_unverified count_dup count_reviewed count_resubmit
    count_ontime=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | awk -F'|' '$9 == "NO" && $8 != "Unverified" && $8 != "Duplicate Suspected"' | wc -l)
    count_late=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | awk -F'|' '$9 == "YES" || $8 == "Late"' | wc -l)
    count_unverified=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | awk -F'|' '$8 == "Unverified"' | wc -l)
    count_dup=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | awk -F'|' '$8 == "Duplicate Suspected"' | wc -l)
    count_reviewed=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | awk -F'|' '$8 == "Reviewed"' | wc -l)
    count_resubmit=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | awk -F'|' '$8 == "Resubmit Required"' | wc -l)

    # Calculate theoretical missing: (total_students * total_assignments) - unique (student, assignment) submissions
    local expected_total=$((total_students * total_assignments))
    local submitted_pairs
    submitted_pairs=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | awk -F'|' '{ print $2 "|" $3 }' | sort -u | wc -l)
    local missing_total=$((expected_total - submitted_pairs))
    if (( missing_total < 0 )); then missing_total=0; fi

    echo -e "${COLOR_CYAN}+------------------------------------------------------------------------------+${COLOR_RESET}"
    printf "${COLOR_CYAN}|${COLOR_RESET} %-44s : ${COLOR_BOLD}%-29s${COLOR_RESET} ${COLOR_CYAN}|${COLOR_RESET}\n" "Total Registered Students" "${total_students}"
    printf "${COLOR_CYAN}|${COLOR_RESET} %-44s : ${COLOR_BOLD}%-29s${COLOR_RESET} ${COLOR_CYAN}|${COLOR_RESET}\n" "Total Assignments Created" "${total_assignments}"
    printf "${COLOR_CYAN}|${COLOR_RESET} %-44s : ${COLOR_BOLD}%-29s${COLOR_RESET} ${COLOR_CYAN}|${COLOR_RESET}\n" "Total Recorded Submissions" "${total_subs}"
    echo -e "${COLOR_CYAN}+------------------------------------------------------------------------------+${COLOR_RESET}"
    printf "${COLOR_CYAN}|${COLOR_RESET} %-44s : ${COLOR_GREEN}%-29s${COLOR_RESET} ${COLOR_CYAN}|${COLOR_RESET}\n" "On-Time Submissions" "${count_ontime}"
    printf "${COLOR_CYAN}|${COLOR_RESET} %-44s : ${COLOR_YELLOW}%-29s${COLOR_RESET} ${COLOR_CYAN}|${COLOR_RESET}\n" "Late Submissions" "${count_late}"
    printf "${COLOR_CYAN}|${COLOR_RESET} %-44s : ${COLOR_RED}%-29s${COLOR_RESET} ${COLOR_CYAN}|${COLOR_RESET}\n" "Not Submitted (Pending/Missing)" "${missing_total}"
    printf "${COLOR_CYAN}|${COLOR_RESET} %-44s : ${COLOR_RED}%-29s${COLOR_RESET} ${COLOR_CYAN}|${COLOR_RESET}\n" "Unverified (Fake / Empty File)" "${count_unverified}"
    printf "${COLOR_CYAN}|${COLOR_RESET} %-44s : ${COLOR_MAGENTA}%-29s${COLOR_RESET} ${COLOR_CYAN}|${COLOR_RESET}\n" "Duplicate Suspected (SHA-256 Collision)" "${count_dup}"
    printf "${COLOR_CYAN}|${COLOR_RESET} %-44s : ${COLOR_CYAN}%-29s${COLOR_RESET} ${COLOR_CYAN}|${COLOR_RESET}\n" "Reviewed by Faculty" "${count_reviewed}"
    printf "${COLOR_CYAN}|${COLOR_RESET} %-44s : ${COLOR_YELLOW}%-29s${COLOR_RESET} ${COLOR_CYAN}|${COLOR_RESET}\n" "Resubmission Required" "${count_resubmit}"
    echo -e "${COLOR_CYAN}+------------------------------------------------------------------------------+${COLOR_RESET}"

    pause
}

# ------------------------------------------------------------------------------
# 4. Generate Reports: TXT and CSV (Module 10)
# ------------------------------------------------------------------------------
generate_reports() {
    print_header "GENERATE COMPREHENSIVE REPORTS"

    local gen_time
    gen_time=$(get_current_timestamp)

    local txt_report="${REPORTS_DIR}/submission_report.txt"
    local csv_report="${REPORTS_DIR}/submission_report.csv"

    local total_students total_assignments total_subs
    total_students=$(tail -n +2 "${STUDENTS_DB}" 2>/dev/null | grep -c . || echo 0)
    total_assignments=$(tail -n +2 "${ASSIGNMENTS_DB}" 2>/dev/null | grep -c . || echo 0)
    total_subs=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | grep -c . || echo 0)

    local count_ontime count_late count_unverified count_dup count_reviewed count_resubmit
    count_ontime=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | awk -F'|' '$9 == "NO" && $8 != "Unverified" && $8 != "Duplicate Suspected"' | wc -l)
    count_late=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | awk -F'|' '$9 == "YES" || $8 == "Late"' | wc -l)
    count_unverified=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | awk -F'|' '$8 == "Unverified"' | wc -l)
    count_dup=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | awk -F'|' '$8 == "Duplicate Suspected"' | wc -l)
    count_reviewed=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | awk -F'|' '$8 == "Reviewed"' | wc -l)
    count_resubmit=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | awk -F'|' '$8 == "Resubmit Required"' | wc -l)

    local expected_total=$((total_students * total_assignments))
    local submitted_pairs
    submitted_pairs=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | awk -F'|' '{ print $2 "|" $3 }' | sort -u | wc -l)
    local missing_total=$((expected_total - submitted_pairs))
    if (( missing_total < 0 )); then missing_total=0; fi

    # --------------------------------------------------------------------------
    # Generate TXT Report
    # --------------------------------------------------------------------------
    {
        echo "====================================================================================================="
        echo " STUDENT ASSIGNMENT SUBMISSION & PLAGIARISM MONITORING SYSTEM"
        echo " COMPREHENSIVE ACADEMIC EVALUATION REPORT"
        echo " Generated On: ${gen_time}"
        echo "====================================================================================================="
        echo ""
        echo "1. EXECUTIVE SUMMARY"
        echo "-----------------------------------------------------------------------------------------------------"
        printf "Total Registered Students              : %d\n" "$total_students"
        printf "Total Assignments Configured           : %d\n" "$total_assignments"
        printf "Total Recorded Submissions             : %d\n" "$total_subs"
        printf "On-Time Submissions                    : %d\n" "$count_ontime"
        printf "Late Submissions                       : %d\n" "$count_late"
        printf "Missing / Not Submitted Assignments    : %d\n" "$missing_total"
        printf "Unverified Submissions (Fake / Empty)  : %d\n" "$count_unverified"
        printf "Duplicate Suspected (SHA-256 Matches)  : %d\n" "$count_dup"
        printf "Reviewed Submissions (Faculty Graded)  : %d\n" "$count_reviewed"
        printf "Resubmission Required Submissions      : %d\n" "$count_resubmit"
        echo "-----------------------------------------------------------------------------------------------------"
        echo ""
        echo "2. DETAILED SUBMISSION AND REVIEW AUDIT TABLE"
        echo "-----------------------------------------------------------------------------------------------------"
        printf "%-9s | %-12s | %-20s | %-10s | %-4s | %-19s | %-18s | %-5s | %-8s | %-20s\n" \
            "SUB_ID" "ROLL_NO" "STUDENT_NAME" "ASGN_ID" "VER" "SUBMITTED_TIME" "STATUS" "GRADE" "FACULTY" "REMARKS"
        echo "--------------------------------------------------------------------------------------------------------------------------------------------------------"

        tail -n +2 "${SUBMISSIONS_DB}" | while IFS='|' read -r sub roll asgn path ts hash ver st late; do
            st_name=$(grep "^${roll}|" "${STUDENTS_DB}" 2>/dev/null | cut -d'|' -f2)
            st_name="${st_name:-Unknown}"

            # Query reviews
            rev_record=$(grep "|${sub}|" "${REVIEWS_DB}" 2>/dev/null | tail -n 1 || true)
            r_grade="Pending"
            r_fac="N/A"
            r_rem="None"
            if [[ -n "$rev_record" ]]; then
                r_fac=$(echo "$rev_record" | cut -d'|' -f5)
                r_grade=$(echo "$rev_record" | cut -d'|' -f7)
                r_rem=$(echo "$rev_record" | cut -d'|' -f9)
            fi

            printf "%-9s | %-12s | %-20.20s | %-10s | %-4s | %-19s | %-18.18s | %-5s | %-8.8s | %-20.20s\n" \
                "$sub" "$roll" "$st_name" "$asgn" "$ver" "$ts" "$st" "$r_grade" "$r_fac" "$r_rem"
        done
        echo "--------------------------------------------------------------------------------------------------------------------------------------------------------"
        echo ""
        echo "3. ACADEMIC INTEGRITY & PLAGIARISM NOTICE"
        echo "-----------------------------------------------------------------------------------------------------"
        echo "Cryptographic SHA-256 hashes identify duplicate byte sequences. Submissions flagged as 'Duplicate"
        echo "Suspected' require faculty evaluation to distinguish between collaborative boilerplates and copying."
        echo "Empty or missing file paths are marked 'Unverified' without pre-judging intent."
        echo "====================================================================================================="
    } > "${txt_report}"

    # --------------------------------------------------------------------------
    # Generate CSV Report
    # --------------------------------------------------------------------------
    {
        echo "SubmissionID,RollNo,StudentName,Department,AssignmentID,Version,SubmittedTime,Status,LateFlag,SHA256,Faculty,Grade,AcceptedStatus,Remarks"

        tail -n +2 "${SUBMISSIONS_DB}" | while IFS='|' read -r sub roll asgn path ts hash ver st late; do
            st_rec=$(grep "^${roll}|" "${STUDENTS_DB}" 2>/dev/null || true)
            st_name=$(echo "$st_rec" | cut -d'|' -f2)
            st_dept=$(echo "$st_rec" | cut -d'|' -f3)
            st_name="${st_name:-Unknown}"
            st_dept="${st_dept:-N/A}"

            rev_record=$(grep "|${sub}|" "${REVIEWS_DB}" 2>/dev/null | tail -n 1 || true)
            r_fac="N/A"
            r_grade="Pending"
            r_acc="Pending"
            r_rem="None"
            if [[ -n "$rev_record" ]]; then
                r_fac=$(echo "$rev_record" | cut -d'|' -f5)
                r_grade=$(echo "$rev_record" | cut -d'|' -f7)
                r_acc=$(echo "$rev_record" | cut -d'|' -f8)
                r_rem=$(echo "$rev_record" | cut -d'|' -f9)
            fi

            # Clean CSV fields
            r_rem_clean=$(echo "$r_rem" | tr '"' "'")
            echo "\"${sub}\",\"${roll}\",\"${st_name}\",\"${st_dept}\",\"${asgn}\",\"${ver}\",\"${ts}\",\"${st}\",\"${late}\",\"${hash}\",\"${r_fac}\",\"${r_grade}\",\"${r_acc}\",\"${r_rem_clean}\""
        done
    } > "${csv_report}"

    print_success "Reports generated successfully!"
    echo "  Plain Text Report: [${txt_report}]"
    echo "  CSV Spreadsheet:   [${csv_report}]"
    pause
}
