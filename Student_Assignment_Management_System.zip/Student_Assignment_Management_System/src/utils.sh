#!/usr/bin/env bash
# ==============================================================================
# STUDENT ASSIGNMENT SUBMISSION & PLAGIARISM MONITORING SYSTEM
# File: src/utils.sh
# Purpose: Shared utilities, ANSI formatting, validation, and database setup
# Compatibility: Ubuntu / Linux / GitHub Codespaces / POSIX Bash
# ==============================================================================

# Ensure standard system utilities are in PATH across all environments
export PATH="/usr/bin:/bin:$PATH"

# Determine absolute project root regardless of execution location
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

# Data and Directory Definitions
DATA_DIR="${PROJECT_ROOT}/data"
UPLOADS_DIR="${PROJECT_ROOT}/uploads/submissions"
SAMPLES_DIR="${PROJECT_ROOT}/uploads/assignment_samples"
REPORTS_DIR="${PROJECT_ROOT}/reports"
SCREENSHOTS_DIR="${PROJECT_ROOT}/screenshots"
DOCS_DIR="${PROJECT_ROOT}/documentation"

STUDENTS_DB="${DATA_DIR}/students.db"
ASSIGNMENTS_DB="${DATA_DIR}/assignments.db"
SUBMISSIONS_DB="${DATA_DIR}/submissions.db"
REVIEWS_DB="${DATA_DIR}/reviews.db"

# ANSI Color Codes for Professional Terminal UI
if [[ -t 1 ]]; then
    COLOR_RESET="\033[0m"
    COLOR_BOLD="\033[1m"
    COLOR_RED="\033[1;31m"
    COLOR_GREEN="\033[1;32m"
    COLOR_YELLOW="\033[1;33m"
    COLOR_BLUE="\033[1;34m"
    COLOR_MAGENTA="\033[1;35m"
    COLOR_CYAN="\033[1;36m"
    COLOR_WHITE="\033[1;37m"
    COLOR_GRAY="\033[0;90m"
    BG_BLUE="\033[44m"
    BG_DARK="\033[40m"
else
    COLOR_RESET=""
    COLOR_BOLD=""
    COLOR_RED=""
    COLOR_GREEN=""
    COLOR_YELLOW=""
    COLOR_BLUE=""
    COLOR_MAGENTA=""
    COLOR_CYAN=""
    COLOR_WHITE=""
    COLOR_GRAY=""
    BG_BLUE=""
    BG_DARK=""
fi

# ==============================================================================
# UI Formatting Functions
# ==============================================================================
print_header() {
    local title="$1"
    echo -e "${COLOR_CYAN}================================================================================${COLOR_RESET}"
    printf "${COLOR_BOLD}${COLOR_WHITE} %-78s ${COLOR_RESET}\n" "${title}"
    echo -e "${COLOR_CYAN}================================================================================${COLOR_RESET}"
}

print_section() {
    local subtitle="$1"
    echo -e "\n${COLOR_BLUE}--- [ ${subtitle} ] ----------------------------------------------------${COLOR_RESET}"
}

print_divider() {
    echo -e "${COLOR_GRAY}--------------------------------------------------------------------------------${COLOR_RESET}"
}

print_success() {
    echo -e "${COLOR_GREEN}[SUCCESS]${COLOR_RESET} $1"
}

print_warning() {
    echo -e "${COLOR_YELLOW}[WARNING]${COLOR_RESET} $1"
}

print_error() {
    echo -e "${COLOR_RED}[ERROR]${COLOR_RESET} $1"
}

print_info() {
    echo -e "${COLOR_CYAN}[INFO]${COLOR_RESET} $1"
}

pause() {
    echo ""
    read -r -p "Press [Enter] to continue..." _
}

# ==============================================================================
# Database Initialization
# ==============================================================================
init_database() {
    mkdir -p "${DATA_DIR}" "${UPLOADS_DIR}" "${SAMPLES_DIR}" "${REPORTS_DIR}" "${SCREENSHOTS_DIR}" "${DOCS_DIR}"

    # Initialize students.db (Header: RollNo|Name|Department|Email|RegisteredDate)
    if [[ ! -f "${STUDENTS_DB}" ]]; then
        echo "ROLL_NO|NAME|DEPARTMENT|EMAIL|REG_DATE" > "${STUDENTS_DB}"
    fi

    # Initialize assignments.db (Header: AssignmentID|Title|Subject|Deadline|CreatedDate)
    if [[ ! -f "${ASSIGNMENTS_DB}" ]]; then
        echo "ASSIGNMENT_ID|TITLE|SUBJECT|DEADLINE|CREATED_DATE" > "${ASSIGNMENTS_DB}"
    fi

    # Initialize submissions.db (Header: SubID|RollNo|AssignmentID|FilePath|Timestamp|SHA256|Version|Status|LateFlag)
    if [[ ! -f "${SUBMISSIONS_DB}" ]]; then
        echo "SUB_ID|ROLL_NO|ASSIGNMENT_ID|FILE_PATH|TIMESTAMP|SHA256|VERSION|STATUS|LATE_FLAG" > "${SUBMISSIONS_DB}"
    fi

    # Initialize reviews.db (Header: ReviewID|SubID|RollNo|AssignmentID|Faculty|Status|Grade|AcceptedStatus|Remarks|ReviewDate)
    if [[ ! -f "${REVIEWS_DB}" ]]; then
        echo "REVIEW_ID|SUB_ID|ROLL_NO|ASSIGNMENT_ID|FACULTY|STATUS|GRADE|ACCEPTED_STATUS|REMARKS|REVIEW_DATE" > "${REVIEWS_DB}"
    fi
}

# ==============================================================================
# Date & Timestamp Validation & Comparison
# Standard Format: YYYY-MM-DD HH:MM:SS
# ==============================================================================
get_current_timestamp() {
    date "+%Y-%m-%d %H:%M:%S"
}

validate_date_format() {
    local dt="$1"
    # Format pattern check: YYYY-MM-DD HH:MM:SS
    if [[ ! "$dt" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}[[:space:]][0-9]{2}:[0-9]{2}:[0-9]{2}$ ]]; then
        return 1
    fi
    # Validate with date utility
    if date -d "$dt" "+%Y-%m-%d %H:%M:%S" >/dev/null 2>&1; then
        return 0
    else
        return 1
    fi
}

to_epoch_seconds() {
    local dt="$1"
    date -d "$dt" "+%s" 2>/dev/null
}

# Returns 0 if time1 <= time2 (on-time), returns 1 if time1 > time2 (late)
is_on_time() {
    local sub_time="$1"
    local deadline="$2"
    local sub_epoch
    local ddl_epoch

    sub_epoch=$(to_epoch_seconds "$sub_time")
    ddl_epoch=$(to_epoch_seconds "$deadline")

    if [[ -z "$sub_epoch" || -z "$ddl_epoch" ]]; then
        return 2 # Date parsing error
    fi

    if (( sub_epoch <= ddl_epoch )); then
        return 0 # On time
    else
        return 1 # Late
    fi
}

# ==============================================================================
# Input Sanitation & Helper
# ==============================================================================
sanitize_string() {
    local input="$1"
    # Remove pipes to protect delimiter structure
    echo "$input" | tr -d '|' | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//'
}
