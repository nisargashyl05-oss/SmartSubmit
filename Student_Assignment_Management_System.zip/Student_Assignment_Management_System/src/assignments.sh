#!/usr/bin/env bash
# ==============================================================================
# STUDENT ASSIGNMENT SUBMISSION & PLAGIARISM MONITORING SYSTEM
# File: src/assignments.sh
# Purpose: Module 2 - Assignment Creation, Listing, and Deadline Modification
# Compatibility: Ubuntu / Linux / GitHub Codespaces / POSIX Bash
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/utils.sh"

# ------------------------------------------------------------------------------
# 1. Create Assignment
# ------------------------------------------------------------------------------
create_assignment() {
    print_header "CREATE NEW ASSIGNMENT"

    local asgn_id title subject deadline created_date

    while true; do
        read -r -p "Enter Assignment ID (e.g. CS501-A1): " asgn_id
        asgn_id=$(sanitize_string "$asgn_id")
        if [[ -z "$asgn_id" ]]; then
            print_error "Assignment ID cannot be empty."
            continue
        fi

        # Prevent duplicate assignment IDs
        if grep -q "^${asgn_id}|" "${ASSIGNMENTS_DB}" 2>/dev/null; then
            print_error "Assignment ID '${asgn_id}' already exists. Please choose a unique ID."
            read -r -p "Try again? (y/n): " retry
            if [[ "$retry" != "y" && "$retry" != "Y" ]]; then
                return 1
            fi
        else
            break
        fi
    done

    while true; do
        read -r -p "Enter Assignment Title: " title
        title=$(sanitize_string "$title")
        if [[ -n "$title" ]]; then break; fi
        print_error "Assignment title cannot be empty."
    done

    while true; do
        read -r -p "Enter Subject Name: " subject
        subject=$(sanitize_string "$subject")
        if [[ -n "$subject" ]]; then break; fi
        print_error "Subject name cannot be empty."
    done

    while true; do
        echo -e "${COLOR_CYAN}Enter Submission Deadline (Format: YYYY-MM-DD HH:MM:SS)${COLOR_RESET}"
        read -r -p "Deadline: " deadline
        deadline=$(sanitize_string "$deadline")

        if validate_date_format "$deadline"; then
            break
        else
            print_error "Invalid date format. Expected 'YYYY-MM-DD HH:MM:SS' (e.g. 2026-12-01 23:59:59)."
        fi
    done

    created_date=$(get_current_timestamp)

    # Append to assignments database
    echo "${asgn_id}|${title}|${subject}|${deadline}|${created_date}" >> "${ASSIGNMENTS_DB}"
    print_success "Assignment '${title}' [${asgn_id}] successfully created."
    echo "Deadline set to: ${deadline}"
    pause
}

# ------------------------------------------------------------------------------
# 2. View All Assignments
# ------------------------------------------------------------------------------
view_assignments() {
    print_header "ASSIGNMENTS DIRECTORY"

    if [[ ! -s "${ASSIGNMENTS_DB}" ]] || [[ $(wc -l < "${ASSIGNMENTS_DB}") -le 1 ]]; then
        print_warning "No assignments found in database."
        pause
        return 0
    fi

    local current_time
    current_time=$(get_current_timestamp)
    local cur_epoch
    cur_epoch=$(to_epoch_seconds "$current_time")

    awk -F'|' -v now_epoch="$cur_epoch" '
    BEGIN {
        printf "+---------------+--------------------------------+----------------------+---------------------+-------------+\n"
        printf "| %-13s | %-30s | %-20s | %-19s | %-11s |\n", "ASSIGNMENT ID", "TITLE", "SUBJECT", "DEADLINE", "STATUS"
        printf "+---------------+--------------------------------+----------------------+---------------------+-------------+\n"
        count = 0
    }
    NR > 1 {
        # Determine active vs closed status
        cmd = "date -d \"" $4 "\" +%s 2>/dev/null"
        cmd | getline ddl_epoch
        close(cmd)

        status = "OPEN"
        if (ddl_epoch != "" && now_epoch > ddl_epoch) {
            status = "EXPIRED"
        }

        printf "| %-13s | %-30.30s | %-20.20s | %-19s | %-11s |\n", $1, $2, $3, $4, status
        count++
    }
    END {
        printf "+---------------+--------------------------------+----------------------+---------------------+-------------+\n"
        printf "Total Assignments: %d\n", count
    }
    ' "${ASSIGNMENTS_DB}"

    pause
}

# ------------------------------------------------------------------------------
# 3. Set / Update Assignment Deadline
# ------------------------------------------------------------------------------
set_assignment_deadline() {
    print_header "UPDATE ASSIGNMENT DEADLINE"

    read -r -p "Enter Assignment ID: " asgn_id
    asgn_id=$(sanitize_string "$asgn_id")

    local record
    record=$(grep "^${asgn_id}|" "${ASSIGNMENTS_DB}" 2>/dev/null || true)

    if [[ -z "$record" ]]; then
        print_error "Assignment with ID '${asgn_id}' not found."
        pause
        return 1
    fi

    local cur_title cur_subj cur_ddl cur_created
    cur_title=$(echo "$record" | cut -d'|' -f2)
    cur_subj=$(echo "$record" | cut -d'|' -f3)
    cur_ddl=$(echo "$record" | cut -d'|' -f4)
    cur_created=$(echo "$record" | cut -d'|' -f5)

    echo -e "${COLOR_YELLOW}Assignment Details:${COLOR_RESET}"
    echo "  Title:            ${cur_title}"
    echo "  Subject:          ${cur_subj}"
    echo "  Current Deadline: ${cur_ddl}"
    print_divider

    local new_ddl
    while true; do
        echo -e "${COLOR_CYAN}Enter New Deadline (Format: YYYY-MM-DD HH:MM:SS)${COLOR_RESET}"
        read -r -p "New Deadline: " new_ddl
        new_ddl=$(sanitize_string "$new_ddl")

        if validate_date_format "$new_ddl"; then
            break
        else
            print_error "Invalid date format. Expected 'YYYY-MM-DD HH:MM:SS' (e.g. 2026-12-15 18:00:00)."
        fi
    done

    local new_record="${asgn_id}|${cur_title}|${cur_subj}|${new_ddl}|${cur_created}"

    # Update using temporary file
    local tmp_db
    tmp_db=$(mktemp "${DATA_DIR}/assignments_tmp.XXXXXX")

    awk -F'|' -v target="$asgn_id" -v replacement="$new_record" '
        $1 == target { print replacement; next }
        { print $0 }
    ' "${ASSIGNMENTS_DB}" > "$tmp_db" && mv "$tmp_db" "${ASSIGNMENTS_DB}"

    print_success "Deadline for Assignment '${asgn_id}' updated successfully to ${new_ddl}."
    pause
}
