#!/usr/bin/env bash
# ==============================================================================
# STUDENT ASSIGNMENT SUBMISSION & PLAGIARISM MONITORING SYSTEM
# File: src/plagiarism.sh
# Purpose: Module 7 - SHA-256 Duplicate Content Detection & Hash Collision Analysis
# Compatibility: Ubuntu / Linux / GitHub Codespaces / POSIX Bash
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/utils.sh"

# ------------------------------------------------------------------------------
# 1. Run Duplicate & Hash Collision Detection
# ------------------------------------------------------------------------------
detect_duplicate_assignments() {
    print_header "DUPLICATE SUBMISSION & CHECKSUM COLLISION MONITOR"

    echo -e "${COLOR_YELLOW}Academic Disclaimer:${COLOR_RESET}"
    echo "  Cryptographic SHA-256 hashing verifies identical binary content."
    echo "  An exact checksum match confirms identical files, but does NOT"
    echo "  automatically prove academic dishonesty (e.g., standard project templates,"
    echo "  code boilerplates, or lab skeletons). Formal faculty review is required."
    print_divider

    read -r -p "Enter Assignment ID to inspect (or press Enter for ALL assignments): " target_asgn
    target_asgn=$(sanitize_string "$target_asgn")

    local filter_pattern="."
    if [[ -n "$target_asgn" ]]; then
        filter_pattern="${target_asgn}"
    fi

    # Find duplicates grouped by AssignmentID and SHA256 (excluding N/A or empty hashes)
    local dup_hashes
    dup_hashes=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | \
        awk -F'|' -v asgn_filter="$filter_pattern" '
            $3 ~ asgn_filter && $6 != "N/A" && $6 != "EMPTY_HASH" && $6 != "" {
                key = $3 "|" $6
                count[key]++
            }
            END {
                for (k in count) {
                    if (count[k] > 1) {
                        print k "|" count[k]
                    }
                }
            }
        ')

    if [[ -z "$dup_hashes" ]]; then
        print_success "No duplicate submissions detected for target filter: '${filter_pattern}'."
        pause
        return 0
    fi

    local log_file="${REPORTS_DIR}/duplicate_detection_log.txt"
    local scan_time
    scan_time=$(get_current_timestamp)

    {
        echo "================================================================================"
        echo "DUPLICATE ASSIGNMENT DETECTION AUDIT REPORT"
        echo "Generated At: ${scan_time}"
        echo "Filter:       ${filter_pattern}"
        echo "================================================================================"
        echo ""
    } > "${log_file}"

    echo -e "${COLOR_RED}[!] DUPLICATE DETECTIONS FOUND:${COLOR_RESET}\n"

    local cluster_num=1
    while IFS='|' read -r asgn hash collision_count; do
        [[ -z "$asgn" ]] && continue

        echo -e "${COLOR_BOLD}${COLOR_MAGENTA}Cluster #${cluster_num} | Assignment: ${asgn} | Collisions: ${collision_count}${COLOR_RESET}"
        echo "SHA-256 Hash: ${hash}"
        print_divider

        {
            echo "--- Cluster #${cluster_num} ---"
            echo "Assignment ID:    ${asgn}"
            echo "Colliding Hash:   ${hash}"
            echo "Matching Records: ${collision_count}"
            printf "%-10s %-15s %-25s %-10s %-20s %-15s\n" "SUB_ID" "ROLL_NO" "STUDENT_NAME" "VERSION" "TIMESTAMP" "STATUS"
            printf "%-10s %-15s %-25s %-10s %-20s %-15s\n" "----------" "---------------" "-------------------------" "----------" "--------------------" "---------------"
        } >> "${log_file}"

        printf "+----------+---------------+---------------------------+---------+---------------------+---------------------+\n"
        printf "| %-8s | %-13s | %-25s | %-7s | %-19s | %-19s |\n", "SUB ID", "ROLL NO", "STUDENT NAME", "VERSION", "TIMESTAMP", "CURRENT STATUS"
        printf "+----------+---------------+---------------------------+---------+---------------------+---------------------+\n"

        # List records participating in this duplicate hash cluster
        tail -n +2 "${SUBMISSIONS_DB}" | awk -F'|' -v cur_asgn="$asgn" -v cur_hash="$hash" -v st_db="${STUDENTS_DB}" '
            $3 == cur_asgn && $6 == cur_hash {
                sub_id = $1
                roll = $2
                ver = $7
                ts = $5
                st = $8

                # Lookup student name
                name = "Unknown"
                while ((getline line < st_db) > 0) {
                    split(line, parts, "|")
                    if (parts[1] == roll) {
                        name = parts[2]
                        break
                    }
                }
                close(st_db)

                printf "| %-8s | %-13s | %-25.25s | %-7s | %-19s | %-19.19s |\n", sub_id, roll, name, ver, ts, st
            }
        '

        # Also append to log file
        tail -n +2 "${SUBMISSIONS_DB}" | awk -F'|' -v cur_asgn="$asgn" -v cur_hash="$hash" -v st_db="${STUDENTS_DB}" '
            $3 == cur_asgn && $6 == cur_hash {
                sub_id = $1
                roll = $2
                ver = $7
                ts = $5
                st = $8
                name = "Unknown"
                while ((getline line < st_db) > 0) {
                    split(line, parts, "|")
                    if (parts[1] == roll) {
                        name = parts[2]
                        break
                    }
                }
                close(st_db)
                printf "%-10s %-15s %-25s %-10s %-20s %-15s\n", sub_id, roll, name, ver, ts, st
            }
        ' >> "${log_file}"

        printf "+----------+---------------+---------------------------+---------+---------------------+---------------------+\n\n"
        echo "" >> "${log_file}"
        cluster_num=$((cluster_num + 1))
    done <<< "$dup_hashes"

    print_info "Duplicate audit log saved to: [${log_file}]"
    pause
}
