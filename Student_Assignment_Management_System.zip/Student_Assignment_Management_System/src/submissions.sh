#!/usr/bin/env bash
# ==============================================================================
# STUDENT ASSIGNMENT SUBMISSION & PLAGIARISM MONITORING SYSTEM
# File: src/submissions.sh
# Purpose: Modules 3, 4, 6 - Submission Processing, Status Engine, Integrity Checks
# Compatibility: Ubuntu / Linux / GitHub Codespaces / POSIX Bash
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/utils.sh"

# ------------------------------------------------------------------------------
# 1. Submit Assignment
# ------------------------------------------------------------------------------
submit_assignment() {
    print_header "SUBMIT STUDENT ASSIGNMENT"

    local roll_no asgn_id file_path

    # Verify student exists
    while true; do
        read -r -p "Enter Student Roll Number: " roll_no
        roll_no=$(sanitize_string "$roll_no")
        if [[ -z "$roll_no" ]]; then
            print_error "Roll number cannot be empty."
            continue
        fi

        if grep -q "^${roll_no}|" "${STUDENTS_DB}" 2>/dev/null; then
            local student_name
            student_name=$(grep "^${roll_no}|" "${STUDENTS_DB}" | cut -d'|' -f2)
            print_info "Student Identified: ${student_name} (${roll_no})"
            break
        else
            print_error "Roll Number '${roll_no}' is not registered. Please register the student first."
            read -r -p "Try again? (y/n): " retry
            if [[ "$retry" != "y" && "$retry" != "Y" ]]; then
                return 1
            fi
        fi
    done

    # Verify assignment exists
    while true; do
        read -r -p "Enter Assignment ID: " asgn_id
        asgn_id=$(sanitize_string "$asgn_id")
        if [[ -z "$asgn_id" ]]; then
            print_error "Assignment ID cannot be empty."
            continue
        fi

        local asgn_record
        asgn_record=$(grep "^${asgn_id}|" "${ASSIGNMENTS_DB}" 2>/dev/null || true)
        if [[ -n "$asgn_record" ]]; then
            local asgn_title asgn_ddl
            asgn_title=$(echo "$asgn_record" | cut -d'|' -f2)
            asgn_ddl=$(echo "$asgn_record" | cut -d'|' -f4)
            print_info "Assignment: '${asgn_title}' | Deadline: ${asgn_ddl}"
            break
        else
            print_error "Assignment ID '${asgn_id}' not found."
            read -r -p "Try again? (y/n): " retry
            if [[ "$retry" != "y" && "$retry" != "Y" ]]; then
                return 1
            fi
        fi
    done

    # Enter and validate submission file
    read -r -p "Enter absolute or relative path to assignment file: " file_path
    file_path=$(sanitize_string "$file_path")

    local sub_time
    sub_time=$(get_current_timestamp)

    local status="Submitted"
    local late_flag="NO"
    local file_hash="N/A"
    local stored_path="N/A"
    local is_valid_file=true

    # Integrity & Fake Submission Checks (Module 6)
    if [[ ! -e "$file_path" ]]; then
        print_warning "FILE INTEGRITY CHECK FAILED: The specified file path does not exist."
        print_info "Note: Non-existent files are flagged as 'Unverified'. This may be an administrative error or path typo."
        status="Unverified"
        stored_path="[MISSING]: $file_path"
        is_valid_file=false
    elif [[ ! -f "$file_path" ]]; then
        print_warning "FILE INTEGRITY CHECK FAILED: The specified path is a directory, not a regular file."
        status="Unverified"
        stored_path="[INVALID_TYPE]: $file_path"
        is_valid_file=false
    elif [[ ! -s "$file_path" ]]; then
        print_warning "FILE INTEGRITY CHECK FAILED: File exists but is completely EMPTY (0 bytes)."
        print_info "Note: Empty submissions are flagged as 'Unverified'. The student should re-upload a valid assignment."
        status="Unverified"
        file_hash=$(sha256sum "$file_path" 2>/dev/null | cut -d' ' -f1)
        file_hash="${file_hash:-EMPTY_HASH}"
        stored_path="[EMPTY_FILE]: $file_path"
        is_valid_file=false
    fi

    # Deadline comparison
    if is_on_time "$sub_time" "$asgn_ddl"; then
        late_flag="NO"
        if [[ "$status" == "Submitted" ]]; then
            print_success "Submission is ON-TIME (Submitted: ${sub_time} | Deadline: ${asgn_ddl})."
        fi
    else
        late_flag="YES"
        if [[ "$status" == "Submitted" ]]; then
            status="Late"
            print_warning "SUBMISSION IS LATE (Submitted: ${sub_time} | Deadline: ${asgn_ddl})."
        fi
    fi

    # Determine Version Number (Resubmissions)
    local prev_count
    prev_count=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | grep -c "^[^|]*|${roll_no}|${asgn_id}|" || true)
    local version="v1"
    if [[ "$prev_count" -gt 0 ]]; then
        local next_ver=$((prev_count + 1))
        version="v${next_ver}"
        print_info "Resubmission detected. New version assigned: ${version}"
    fi

    # Process valid file archiving and hash computation
    if [[ "$is_valid_file" == true ]]; then
        local base_filename
        base_filename=$(basename "$file_path")
        local safe_dest="${UPLOADS_DIR}/${asgn_id}_${roll_no}_${version}_${base_filename}"
        cp "$file_path" "$safe_dest"
        stored_path="$safe_dest"

        # Compute SHA-256 hash
        file_hash=$(sha256sum "$safe_dest" | cut -d' ' -f1)
        print_info "SHA-256 Checksum: ${file_hash}"

        # Check for duplicate submission collision (Module 7)
        local duplicate_collision
        duplicate_collision=$(awk -F'|' -v hash="$file_hash" -v cur_roll="$roll_no" -v asgn="$asgn_id" '
            $3 == asgn && $6 == hash && $2 != cur_roll {
                print $2 "|" $1
            }
        ' "${SUBMISSIONS_DB}" 2>/dev/null | head -n 1)

        if [[ -n "$duplicate_collision" ]]; then
            local matching_roll matching_sub
            matching_roll=$(echo "$duplicate_collision" | cut -d'|' -f1)
            matching_sub=$(echo "$duplicate_collision" | cut -d'|' -f2)

            print_warning "DUPLICATE CONTENT DETECTED!"
            echo "Identical SHA-256 hash collides with previous submission by Roll No: ${matching_roll} (Sub ID: ${matching_sub})"
            echo -e "${COLOR_YELLOW}Educational Note: Identical checksums confirm matching binary contents.${COLOR_RESET}"
            echo -e "${COLOR_YELLOW}This requires Faculty Plagiarism Review (Status set to 'Duplicate Suspected').${COLOR_RESET}"
            status="Duplicate Suspected"
        fi
    fi

    # Generate unique Submission ID (e.g. SUB-1001)
    local last_num
    last_num=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | awk -F'|' '$1 ~ /^SUB-[0-9]+/ { gsub("SUB-", "", $1); if ($1 > max) max = $1 } END { print (max ? max : 1000) }')
    local new_num=$((last_num + 1))
    local sub_id="SUB-${new_num}"

    # Record to submissions database
    echo "${sub_id}|${roll_no}|${asgn_id}|${stored_path}|${sub_time}|${file_hash}|${version}|${status}|${late_flag}" >> "${SUBMISSIONS_DB}"

    print_divider
    print_success "Submission successfully recorded!"
    echo "  Submission ID: ${sub_id}"
    echo "  Student Roll:  ${roll_no}"
    echo "  Assignment ID: ${asgn_id}"
    echo "  Version:       ${version}"
    echo "  Status:        ${status}"
    echo "  Late Flag:     ${late_flag}"
    echo "  Timestamp:     ${sub_time}"
    pause
}

# ------------------------------------------------------------------------------
# 2. View Submission Records
# ------------------------------------------------------------------------------
view_submissions() {
    print_header "SUBMISSION AUDIT TRAIL"

    if [[ ! -s "${SUBMISSIONS_DB}" ]] || [[ $(wc -l < "${SUBMISSIONS_DB}") -le 1 ]]; then
        print_warning "No submissions recorded yet."
        pause
        return 0
    fi

    awk -F'|' '
    BEGIN {
        printf "+----------+---------------+---------------+---------+---------------------+---------------------+------+\n"
        printf "| %-8s | %-13s | %-13s | %-7s | %-19s | %-19s | %-4s |\n", "SUB ID", "ROLL NO", "ASSIGNMENT", "VERSION", "TIMESTAMP", "STATUS", "LATE"
        printf "+----------+---------------+---------------+---------+---------------------+---------------------+------+\n"
        count = 0
    }
    NR > 1 {
        printf "| %-8s | %-13s | %-13s | %-7s | %-19s | %-19.19s | %-4s |\n", $1, $2, $3, $7, $5, $8, $9
        count++
    }
    END {
        printf "+----------+---------------+---------------+---------+---------------------+---------------------+------+\n"
        printf "Total Recorded Submissions: %d\n", count
    }
    ' "${SUBMISSIONS_DB}"

    pause
}

# ------------------------------------------------------------------------------
# 3. Search Submissions
# ------------------------------------------------------------------------------
search_submissions() {
    print_header "SEARCH SUBMISSION RECORDS"

    read -r -p "Enter search query (Submission ID, Roll No, or Assignment ID): " query
    query=$(sanitize_string "$query")

    if [[ -z "$query" ]]; then
        print_error "Search query cannot be empty."
        pause
        return 1
    fi

    local matches
    matches=$(tail -n +2 "${SUBMISSIONS_DB}" | grep -i "$query" || true)

    if [[ -z "$matches" ]]; then
        print_warning "No submissions found matching: '${query}'"
    else
        echo -e "\n${COLOR_GREEN}Search Results for '${query}':${COLOR_RESET}\n"
        echo "$matches" | awk -F'|' '
        BEGIN {
            printf "+----------+---------------+---------------+---------+---------------------+---------------------+------+\n"
            printf "| %-8s | %-13s | %-13s | %-7s | %-19s | %-19s | %-4s |\n", "SUB ID", "ROLL NO", "ASSIGNMENT", "VERSION", "TIMESTAMP", "STATUS", "LATE"
            printf "+----------+---------------+---------------+---------+---------------------+---------------------+------+\n"
        }
        {
            printf "| %-8s | %-13s | %-13s | %-7s | %-19s | %-19.19s | %-4s |\n", $1, $2, $3, $7, $5, $8, $9
        }
        END {
            printf "+----------+---------------+---------------+---------+---------------------+---------------------+------+\n"
        }
        '
    fi

    pause
}

# ------------------------------------------------------------------------------
# 4. Update Submission Status
# ------------------------------------------------------------------------------
update_submission_status() {
    print_header "UPDATE SUBMISSION STATUS"

    read -r -p "Enter Submission ID (e.g. SUB-1001): " sub_id
    sub_id=$(sanitize_string "$sub_id")

    local record
    record=$(grep "^${sub_id}|" "${SUBMISSIONS_DB}" 2>/dev/null || true)

    if [[ -z "$record" ]]; then
        print_error "Submission ID '${sub_id}' not found."
        pause
        return 1
    fi

    local cur_roll cur_asgn cur_path cur_time cur_hash cur_ver cur_status cur_late
    cur_roll=$(echo "$record" | cut -d'|' -f2)
    cur_asgn=$(echo "$record" | cut -d'|' -f3)
    cur_path=$(echo "$record" | cut -d'|' -f4)
    cur_time=$(echo "$record" | cut -d'|' -f5)
    cur_hash=$(echo "$record" | cut -d'|' -f6)
    cur_ver=$(echo "$record" | cut -d'|' -f7)
    cur_status=$(echo "$record" | cut -d'|' -f8)
    cur_late=$(echo "$record" | cut -d'|' -f9)

    echo -e "${COLOR_YELLOW}Current Record:${COLOR_RESET}"
    echo "  Submission ID:  ${sub_id}"
    echo "  Student Roll:   ${cur_roll}"
    echo "  Assignment ID:  ${cur_asgn}"
    echo "  Current Status: ${cur_status}"
    echo "  File Path:      ${cur_path}"
    print_divider

    echo "Select New Status:"
    echo "  1) Submitted"
    echo "  2) Late"
    echo "  3) Unverified"
    echo "  4) Duplicate Suspected"
    echo "  5) Under Review"
    echo "  6) Reviewed"
    echo "  7) Resubmit Required"

    read -r -p "Enter choice [1-7]: " st_choice
    local new_status="$cur_status"
    case "$st_choice" in
        1) new_status="Submitted" ;;
        2) new_status="Late" ;;
        3) new_status="Unverified" ;;
        4) new_status="Duplicate Suspected" ;;
        5) new_status="Under Review" ;;
        6) new_status="Reviewed" ;;
        7) new_status="Resubmit Required" ;;
        *) print_warning "Invalid selection. Status unchanged." ;;
    esac

    local new_record="${sub_id}|${cur_roll}|${cur_asgn}|${cur_path}|${cur_time}|${cur_hash}|${cur_ver}|${new_status}|${cur_late}"

    # Update database
    local tmp_db
    tmp_db=$(mktemp "${DATA_DIR}/sub_tmp.XXXXXX")
    awk -F'|' -v target="$sub_id" -v replacement="$new_record" '
        $1 == target { print replacement; next }
        { print $0 }
    ' "${SUBMISSIONS_DB}" > "$tmp_db" && mv "$tmp_db" "${SUBMISSIONS_DB}"

    print_success "Submission status for '${sub_id}' updated from '${cur_status}' to '${new_status}'."
    pause
}
