#!/usr/bin/env bash
# ==============================================================================
# STUDENT ASSIGNMENT SUBMISSION & PLAGIARISM MONITORING SYSTEM
# File: src/students.sh
# Purpose: Module 1 - Student Registration, Query, Update, and Deletion
# Compatibility: Ubuntu / Linux / GitHub Codespaces / POSIX Bash
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/utils.sh"

# ------------------------------------------------------------------------------
# 1. Register Student
# ------------------------------------------------------------------------------
register_student() {
    print_header "STUDENT REGISTRATION"
    
    local roll_no name dept email reg_date

    while true; do
        read -r -p "Enter Roll Number (e.g. CS2024-001): " roll_no
        roll_no=$(sanitize_string "$roll_no")
        if [[ -z "$roll_no" ]]; then
            print_error "Roll number cannot be empty."
            continue
        fi

        # Check for duplicate roll number using grep
        if grep -q "^${roll_no}|" "${STUDENTS_DB}" 2>/dev/null; then
            print_error "Roll Number '${roll_no}' already exists in database. Duplicate registration prevented!"
            read -r -p "Try again? (y/n): " retry
            if [[ "$retry" != "y" && "$retry" != "Y" ]]; then
                return 1
            fi
        else
            break
        fi
    done

    while true; do
        read -r -p "Enter Student Full Name: " name
        name=$(sanitize_string "$name")
        if [[ -n "$name" ]]; then break; fi
        print_error "Student name cannot be empty."
    done

    read -r -p "Enter Department (Default: Computer Science): " dept
    dept=$(sanitize_string "$dept")
    dept="${dept:-Computer Science}"

    while true; do
        read -r -p "Enter Student Email: " email
        email=$(sanitize_string "$email")
        if [[ "$email" =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]]; then
            break
        else
            print_warning "Invalid email format. Please provide a valid email (e.g. student@univ.edu)."
        fi
    done

    reg_date=$(get_current_timestamp)

    # Append to database
    echo "${roll_no}|${name}|${dept}|${email}|${reg_date}" >> "${STUDENTS_DB}"
    print_success "Student '${name}' (${roll_no}) successfully registered on ${reg_date}."
    pause
}

# ------------------------------------------------------------------------------
# 2. View All Students
# ------------------------------------------------------------------------------
view_students() {
    print_header "REGISTERED STUDENTS DIRECTORY"
    
    if [[ ! -s "${STUDENTS_DB}" ]] || [[ $(wc -l < "${STUDENTS_DB}") -le 1 ]]; then
        print_warning "No registered students found in database."
        pause
        return 0
    fi

    # Display table using awk
    awk -F'|' '
    BEGIN {
        printf "+---------------+----------------------+----------------------+---------------------------+---------------------+\n"
        printf "| %-13s | %-20s | %-20s | %-25s | %-19s |\n", "ROLL NO", "STUDENT NAME", "DEPARTMENT", "EMAIL ADDRESS", "REG DATE"
        printf "+---------------+----------------------+----------------------+---------------------------+---------------------+\n"
        count = 0
    }
    NR > 1 {
        printf "| %-13s | %-20s | %-20s | %-25s | %-19s |\n", $1, $2, $3, $4, $5
        count++
    }
    END {
        printf "+---------------+----------------------+----------------------+---------------------------+---------------------+\n"
        printf "Total Registered Students: %d\n", count
    }
    ' "${STUDENTS_DB}"

    pause
}

# ------------------------------------------------------------------------------
# 3. Search Students
# ------------------------------------------------------------------------------
search_students() {
    print_header "SEARCH STUDENT RECORDS"
    
    read -r -p "Enter search query (Roll No, Name, or Department): " query
    query=$(sanitize_string "$query")

    if [[ -z "$query" ]]; then
        print_error "Search query cannot be empty."
        pause
        return 1
    fi

    local matches
    matches=$(tail -n +2 "${STUDENTS_DB}" | grep -i "$query" || true)

    if [[ -z "$matches" ]]; then
        print_warning "No student records matched search query: '${query}'"
    else
        echo -e "\n${COLOR_GREEN}Search Results for '${query}':${COLOR_RESET}\n"
        echo "$matches" | awk -F'|' '
        BEGIN {
            printf "+---------------+----------------------+----------------------+---------------------------+---------------------+\n"
            printf "| %-13s | %-20s | %-20s | %-25s | %-19s |\n", "ROLL NO", "STUDENT NAME", "DEPARTMENT", "EMAIL ADDRESS", "REG DATE"
            printf "+---------------+----------------------+----------------------+---------------------------+---------------------+\n"
        }
        {
            printf "| %-13s | %-20s | %-20s | %-25s | %-19s |\n", $1, $2, $3, $4, $5
        }
        END {
            printf "+---------------+----------------------+----------------------+---------------------------+---------------------+\n"
        }
        '
    fi

    pause
}

# ------------------------------------------------------------------------------
# 4. Update Student Details
# ------------------------------------------------------------------------------
update_student() {
    print_header "UPDATE STUDENT DETAILS"
    
    read -r -p "Enter Roll Number of student to update: " roll_no
    roll_no=$(sanitize_string "$roll_no")

    local record
    record=$(grep "^${roll_no}|" "${STUDENTS_DB}" 2>/dev/null || true)

    if [[ -z "$record" ]]; then
        print_error "Student with Roll Number '${roll_no}' not found."
        pause
        return 1
    fi

    local cur_name cur_dept cur_email cur_date
    cur_name=$(echo "$record" | cut -d'|' -f2)
    cur_dept=$(echo "$record" | cut -d'|' -f3)
    cur_email=$(echo "$record" | cut -d'|' -f4)
    cur_date=$(echo "$record" | cut -d'|' -f5)

    echo -e "${COLOR_YELLOW}Current details:${COLOR_RESET}"
    echo "  Name:       ${cur_name}"
    echo "  Department: ${cur_dept}"
    echo "  Email:      ${cur_email}"
    print_divider

    read -r -p "New Name (Leave blank to keep '${cur_name}'): " new_name
    new_name=$(sanitize_string "$new_name")
    new_name="${new_name:-$cur_name}"

    read -r -p "New Department (Leave blank to keep '${cur_dept}'): " new_dept
    new_dept=$(sanitize_string "$new_dept")
    new_dept="${new_dept:-$cur_dept}"

    read -r -p "New Email (Leave blank to keep '${cur_email}'): " new_email
    new_email=$(sanitize_string "$new_email")
    new_email="${new_email:-$cur_email}"

    local new_record="${roll_no}|${new_name}|${new_dept}|${new_email}|${cur_date}"

    # Safe update using temporary file
    local tmp_db
    tmp_db=$(mktemp "${DATA_DIR}/students_tmp.XXXXXX")
    
    awk -F'|' -v target="$roll_no" -v replacement="$new_record" '
        $1 == target { print replacement; next }
        { print $0 }
    ' "${STUDENTS_DB}" > "$tmp_db" && mv "$tmp_db" "${STUDENTS_DB}"

    print_success "Student record for Roll Number '${roll_no}' successfully updated."
    pause
}

# ------------------------------------------------------------------------------
# 5. Delete Student Record
# ------------------------------------------------------------------------------
delete_student() {
    print_header "DELETE STUDENT RECORD"
    
    read -r -p "Enter Roll Number of student to delete: " roll_no
    roll_no=$(sanitize_string "$roll_no")

    local record
    record=$(grep "^${roll_no}|" "${STUDENTS_DB}" 2>/dev/null || true)

    if [[ -z "$record" ]]; then
        print_error "Student with Roll Number '${roll_no}' not found."
        pause
        return 1
    fi

    local student_name
    student_name=$(echo "$record" | cut -d'|' -f2)

    # Check if student has active submissions
    local sub_count
    sub_count=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | grep -c "^[^|]*|${roll_no}|" || true)

    if [[ "$sub_count" -gt 0 ]]; then
        print_warning "Student '${student_name}' has ${sub_count} associated submission record(s)."
        read -r -p "Deleting this student will retain submission archives. Confirm deletion? (yes/no): " confirm
    else
        read -r -p "Are you sure you want to delete student '${student_name}' (${roll_no})? (yes/no): " confirm
    fi

    if [[ "$confirm" != "yes" && "$confirm" != "YES" ]]; then
        print_info "Student deletion cancelled."
        pause
        return 0
    fi

    # Safe deletion using temporary file
    local tmp_db
    tmp_db=$(mktemp "${DATA_DIR}/students_tmp.XXXXXX")
    
    awk -F'|' -v target="$roll_no" '
        $1 != target { print $0 }
    ' "${STUDENTS_DB}" > "$tmp_db" && mv "$tmp_db" "${STUDENTS_DB}"

    print_success "Student record for Roll Number '${roll_no}' successfully deleted."
    pause
}
