#!/usr/bin/env bash
# ==============================================================================
# STUDENT ASSIGNMENT SUBMISSION & PLAGIARISM MONITORING SYSTEM
# File: src/main.sh
# Purpose: Master interactive terminal dashboard and 19-option main menu
# Compatibility: Ubuntu / Linux / GitHub Codespaces / POSIX Bash
# ==============================================================================

# Ensure script directory and utilities are loaded
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/utils.sh"
source "${SCRIPT_DIR}/students.sh"
source "${SCRIPT_DIR}/assignments.sh"
source "${SCRIPT_DIR}/submissions.sh"
source "${SCRIPT_DIR}/plagiarism.sh"
source "${SCRIPT_DIR}/remarks.sh"
source "${SCRIPT_DIR}/reports.sh"

# Initialize databases and directories
init_database

# ------------------------------------------------------------------------------
# Display Top Summary Banner
# ------------------------------------------------------------------------------
display_summary_banner() {
    local total_students total_assignments total_subs count_late count_dup
    total_students=$(tail -n +2 "${STUDENTS_DB}" 2>/dev/null | grep -c . || echo 0)
    total_assignments=$(tail -n +2 "${ASSIGNMENTS_DB}" 2>/dev/null | grep -c . || echo 0)
    total_subs=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | grep -c . || echo 0)
    count_late=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | awk -F'|' '$9 == "YES" || $8 == "Late"' | wc -l)
    count_dup=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | awk -F'|' '$8 == "Duplicate Suspected"' | wc -l)

    local expected_total=$((total_students * total_assignments))
    local submitted_pairs
    submitted_pairs=$(tail -n +2 "${SUBMISSIONS_DB}" 2>/dev/null | awk -F'|' '{ print $2 "|" $3 }' | sort -u | wc -l)
    local missing_total=$((expected_total - submitted_pairs))
    if (( missing_total < 0 )); then missing_total=0; fi

    echo -e "${COLOR_CYAN}================================================================================${COLOR_RESET}"
    echo -e "${COLOR_BOLD}${COLOR_WHITE}  STUDENT ASSIGNMENT SUBMISSION & PLAGIARISM MONITORING SYSTEM (v2.0)            ${COLOR_RESET}"
    echo -e "${COLOR_CYAN}================================================================================${COLOR_RESET}"
    printf "${COLOR_GRAY} Total Students: ${COLOR_WHITE}%-3d${COLOR_RESET} | ${COLOR_GRAY}Assignments: ${COLOR_WHITE}%-2d${COLOR_RESET} | ${COLOR_GRAY}Submitted: ${COLOR_GREEN}%-3d${COLOR_RESET} | ${COLOR_GRAY}Not Submitted: ${COLOR_RED}%-3d${COLOR_RESET} | ${COLOR_GRAY}Late: ${COLOR_YELLOW}%-2d${COLOR_RESET} | ${COLOR_GRAY}Dup Suspected: ${COLOR_MAGENTA}%-2d${COLOR_RESET}\n" \
        "$total_students" "$total_assignments" "$total_subs" "$missing_total" "$count_late" "$count_dup"
    echo -e "${COLOR_CYAN}================================================================================${COLOR_RESET}"
}

# ------------------------------------------------------------------------------
# Master Main Menu Loop
# ------------------------------------------------------------------------------
main_menu() {
    while true; do
        clear 2>/dev/null || echo ""
        display_summary_banner

        echo -e "${COLOR_BOLD}${COLOR_BLUE}--- [ STUDENT MANAGEMENT ] ---------------------------------------------------${COLOR_RESET}"
        echo "  1. Student Registration          2. View Students"
        echo "  3. Update Student Details        4. Delete Student"
        echo ""
        echo -e "${COLOR_BOLD}${COLOR_BLUE}--- [ ASSIGNMENT MANAGEMENT ] ------------------------------------------------${COLOR_RESET}"
        echo "  5. Create Assignment             6. View Assignments"
        echo "  7. Set Assignment Deadline"
        echo ""
        echo -e "${COLOR_BOLD}${COLOR_BLUE}--- [ SUBMISSIONS & MONITORING ] ---------------------------------------------${COLOR_RESET}"
        echo "  8. Submit Assignment             9. View Submission Records"
        echo " 10. Search Submission            11. Update Submission Status"
        echo ""
        echo -e "${COLOR_BOLD}${COLOR_BLUE}--- [ PLAGIARISM & FACULTY EVALUATION ] --------------------------------------${COLOR_RESET}"
        echo " 12. Add Faculty Remarks          13. Check Missing Submissions"
        echo " 14. Check Late Submissions       15. Detect Duplicate Assignments"
        echo " 16. Plagiarism Review"
        echo ""
        echo -e "${COLOR_BOLD}${COLOR_BLUE}--- [ SYSTEM & REPORTING ] ---------------------------------------------------${COLOR_RESET}"
        echo " 17. Generate Reports (TXT/CSV)   18. View Dashboard Statistics"
        echo " 19. Exit"
        echo -e "${COLOR_CYAN}================================================================================${COLOR_RESET}"

        local choice
        read -r -p "Enter your choice [1-19]: " choice
        choice=$(sanitize_string "$choice")

        case "$choice" in
            1)  register_student ;;
            2)  view_students ;;
            3)  update_student ;;
            4)  delete_student ;;
            5)  create_assignment ;;
            6)  view_assignments ;;
            7)  set_assignment_deadline ;;
            8)  submit_assignment ;;
            9)  view_submissions ;;
            10) search_submissions ;;
            11) update_submission_status ;;
            12) add_faculty_remarks ;;
            13) check_missing_submissions ;;
            14) check_late_submissions ;;
            15) detect_duplicate_assignments ;;
            16) plagiarism_review ;;
            17) generate_reports ;;
            18) view_dashboard_statistics ;;
            19)
                echo ""
                print_info "Thank you for using the Student Assignment Management System. Goodbye!"
                echo ""
                exit 0
                ;;
            *)
                print_error "Invalid selection '${choice}'. Please enter a number between 1 and 19."
                pause
                ;;
        esac
    done
}

# Entrypoint
main_menu
