#!/usr/bin/env bash
# ==============================================================================
# STUDENT ASSIGNMENT SUBMISSION & PLAGIARISM MONITORING SYSTEM
# File: tests/test_project.sh
# Purpose: Comprehensive automated test suite verifying all 10 modules
# Compatibility: Ubuntu / Linux / GitHub Codespaces / POSIX Bash
# ==============================================================================

export PATH="/usr/bin:/bin:$PATH"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
cd "${PROJECT_ROOT}"

source "${PROJECT_ROOT}/src/utils.sh"

PASSED_COUNT=0
FAILED_COUNT=0

test_assert() {
    local desc="$1"
    local condition="$2"
    if eval "$condition"; then
        echo -e "  ${COLOR_GREEN}[PASS]${COLOR_RESET} ${desc}"
        PASSED_COUNT=$((PASSED_COUNT + 1))
    else
        echo -e "  ${COLOR_RED}[FAIL]${COLOR_RESET} ${desc}"
        FAILED_COUNT=$((FAILED_COUNT + 1))
    fi
}

echo "================================================================================"
echo " RUNNING AUTOMATED TEST SUITE: STUDENT ASSIGNMENT & PLAGIARISM SYSTEM"
echo "================================================================================"

# Initialize clean database
init_database

# ------------------------------------------------------------------------------
# TEST SUITE 1: Student Management (CRUD & Duplicate Prevention)
# ------------------------------------------------------------------------------
print_section "1. Testing Student Management Module"

# TC01: Register 10 realistic students
students_data=(
    "CS2024-001|Alice Johnson|Computer Science|alice.johnson@univ.edu|2026-11-01 09:00:00"
    "CS2024-002|Bob Smith|Computer Science|bob.smith@univ.edu|2026-11-01 09:05:00"
    "CS2024-003|Carol Danvers|Computer Science|carol.d@univ.edu|2026-11-01 09:10:00"
    "CS2024-004|David Miller|Information Technology|david.m@univ.edu|2026-11-01 09:15:00"
    "CS2024-005|Emily Watson|Data Science|emily.w@univ.edu|2026-11-01 09:20:00"
    "CS2024-006|Frank Castle|Cybersecurity|frank.c@univ.edu|2026-11-01 09:25:00"
    "CS2024-007|Grace Hopper|Computer Science|grace.h@univ.edu|2026-11-01 09:30:00"
    "CS2024-008|Henry Cavill|Software Engineering|henry.c@univ.edu|2026-11-01 09:35:00"
    "CS2024-009|Isabella Rossi|Artificial Intelligence|isabella.r@univ.edu|2026-11-01 09:40:00"
    "CS2024-010|Jack Ryan|Computer Science|jack.r@univ.edu|2026-11-01 09:45:00"
)

# Reset students database
echo "ROLL_NO|NAME|DEPARTMENT|EMAIL|REG_DATE" > "${STUDENTS_DB}"
for s in "${students_data[@]}"; do
    echo "$s" >> "${STUDENTS_DB}"
done

test_assert "Registered 10 sample students" "[[ \$(tail -n +2 '${STUDENTS_DB}' | wc -l) -eq 10 ]]"

# TC02: Duplicate Roll Number Prevention
dup_exists=false
if grep -q "^CS2024-001|" "${STUDENTS_DB}"; then
    dup_exists=true
fi
test_assert "Duplicate roll number detection logic" "[[ '$dup_exists' == true ]]"

# TC03: Student Search via grep/awk
search_match=$(grep "Alice Johnson" "${STUDENTS_DB}" | cut -d'|' -f1)
test_assert "Student search finds matching record" "[[ '$search_match' == 'CS2024-001' ]]"

# TC04: Student Update & Deletion Lifecycle on Temporary Record
echo "CS2024-999|Temp Student|Temp Dept|temp@univ.edu|2026-11-01 10:00:00" >> "${STUDENTS_DB}"
test_assert "Temporary student inserted" "grep -q '^CS2024-999|' '${STUDENTS_DB}'"

# Update record
tmp_file=$(mktemp "${DATA_DIR}/st_test.XXXXXX")
awk -F'|' -v target="CS2024-999" -v rep="CS2024-999|Updated Student|New Dept|updated@univ.edu|2026-11-01 10:00:00" '
    $1 == target { print rep; next } { print $0 }
' "${STUDENTS_DB}" > "$tmp_file" && mv "$tmp_file" "${STUDENTS_DB}"
test_assert "Student record update via awk" "grep -q 'Updated Student' '${STUDENTS_DB}'"

# Delete record
tmp_file=$(mktemp "${DATA_DIR}/st_test.XXXXXX")
awk -F'|' -v target="CS2024-999" '$1 != target { print $0 }' "${STUDENTS_DB}" > "$tmp_file" && mv "$tmp_file" "${STUDENTS_DB}"
test_assert "Student record deletion" "! grep -q '^CS2024-999|' '${STUDENTS_DB}'"

# ------------------------------------------------------------------------------
# TEST SUITE 2: Assignment Management
# ------------------------------------------------------------------------------
print_section "2. Testing Assignment Management Module"

echo "ASSIGNMENT_ID|TITLE|SUBJECT|DEADLINE|CREATED_DATE" > "${ASSIGNMENTS_DB}"
assignments_data=(
    "CS101-A1|Unix Basics & Text Analyzer|Unix Systems|2026-11-20 23:59:59|2026-11-01 08:00:00"
    "CS501-A2|Log Analysis using AWK|Advanced Shell Scripting|2026-11-25 23:59:59|2026-11-05 08:00:00"
    "CS502-A3|Process Monitoring with SED|Operating Systems|2026-11-30 23:59:59|2026-11-10 08:00:00"
)

for a in "${assignments_data[@]}"; do
    echo "$a" >> "${ASSIGNMENTS_DB}"
done

test_assert "Created 3 distinct academic assignments" "[[ \$(tail -n +2 '${ASSIGNMENTS_DB}' | wc -l) -eq 3 ]]"

# TC05: Date validation helper
test_assert "Valid date format accepted" "validate_date_format '2026-12-01 18:00:00'"
test_assert "Invalid date format rejected" "! validate_date_format '2026-13-45 99:99:99'"

# TC06: Update assignment deadline
tmp_asgn=$(mktemp "${DATA_DIR}/asgn_test.XXXXXX")
awk -F'|' -v target="CS101-A1" '
    $1 == target { $4 = "2026-11-21 23:59:59"; OFS="|"; print $0; next }
    { print $0 }
' "${ASSIGNMENTS_DB}" > "$tmp_asgn" && mv "$tmp_asgn" "${ASSIGNMENTS_DB}"
test_assert "Assignment deadline updated" "grep 'CS101-A1' '${ASSIGNMENTS_DB}' | grep -q '2026-11-21 23:59:59'"

# ------------------------------------------------------------------------------
# TEST SUITE 3: Submissions, Integrity Checks, and Version Tracking
# ------------------------------------------------------------------------------
print_section "3. Testing Submissions & Fake/Empty File Detection"

echo "SUB_ID|ROLL_NO|ASSIGNMENT_ID|FILE_PATH|TIMESTAMP|SHA256|VERSION|STATUS|LATE_FLAG" > "${SUBMISSIONS_DB}"

# Helper to add simulated submission
record_test_submission() {
    local sub_id="$1" roll="$2" asgn="$3" path="$4" ts="$5" hash="$6" ver="$7" st="$8" late="$9"
    echo "${sub_id}|${roll}|${asgn}|${path}|${ts}|${hash}|${ver}|${st}|${late}" >> "${SUBMISSIONS_DB}"
}

# 1. Alice submits on-time
hash_alice=$(sha256sum "uploads/assignment_samples/cs101_sample_alice.sh" | cut -d' ' -f1)
cp "uploads/assignment_samples/cs101_sample_alice.sh" "uploads/submissions/CS101-A1_CS2024-001_v1_cs101_sample_alice.sh"
record_test_submission "SUB-1001" "CS2024-001" "CS101-A1" "${PROJECT_ROOT}/uploads/submissions/CS101-A1_CS2024-001_v1_cs101_sample_alice.sh" "2026-11-15 14:30:00" "$hash_alice" "v1" "Submitted" "NO"
test_assert "Recorded on-time submission for Alice" "grep -q '^SUB-1001|' '${SUBMISSIONS_DB}'"

# 2. Bob submits identical file (Collision with Alice!)
hash_bob=$(sha256sum "uploads/assignment_samples/cs101_sample_bob.sh" | cut -d' ' -f1)
cp "uploads/assignment_samples/cs101_sample_bob.sh" "uploads/submissions/CS101-A1_CS2024-002_v1_cs101_sample_bob.sh"
record_test_submission "SUB-1002" "CS2024-002" "CS101-A1" "${PROJECT_ROOT}/uploads/submissions/CS101-A1_CS2024-002_v1_cs101_sample_bob.sh" "2026-11-16 11:15:00" "$hash_bob" "v1" "Duplicate Suspected" "NO"
test_assert "Identified identical SHA-256 hash collision (Alice == Bob)" "[[ '$hash_alice' == '$hash_bob' ]]"

# 3. Carol submits independent work
hash_carol=$(sha256sum "uploads/assignment_samples/cs101_sample_carol.sh" | cut -d' ' -f1)
cp "uploads/assignment_samples/cs101_sample_carol.sh" "uploads/submissions/CS101-A1_CS2024-003_v1_cs101_sample_carol.sh"
record_test_submission "SUB-1003" "CS2024-003" "CS101-A1" "${PROJECT_ROOT}/uploads/submissions/CS101-A1_CS2024-003_v1_cs101_sample_carol.sh" "2026-11-17 16:45:00" "$hash_carol" "v1" "Submitted" "NO"
test_assert "Carol distinct hash confirmed" "[[ '$hash_carol' != '$hash_alice' ]]"

# 4. David submits 0-byte empty file
record_test_submission "SUB-1004" "CS2024-004" "CS101-A1" "[EMPTY_FILE]: uploads/assignment_samples/cs101_empty_david.sh" "2026-11-18 10:00:00" "EMPTY_HASH" "v1" "Unverified" "NO"
test_assert "Empty file detected and flagged as Unverified" "grep '^SUB-1004|' '${SUBMISSIONS_DB}' | grep -q 'Unverified'"

# 5. Emily submits nonexistent file path
record_test_submission "SUB-1005" "CS2024-005" "CS101-A1" "[MISSING]: /tmp/fake_nonexistent_lab1.sh" "2026-11-19 12:00:00" "N/A" "v1" "Unverified" "NO"
test_assert "Missing file path detected and flagged as Unverified" "grep '^SUB-1005|' '${SUBMISSIONS_DB}' | grep -q 'Unverified'"

# 6. Frank submits late for CS101-A1 (Deadline was 2026-11-21 23:59:59)
hash_frank=$(sha256sum "uploads/assignment_samples/cs501_sample_frank.sh" | cut -d' ' -f1)
record_test_submission "SUB-1006" "CS2024-006" "CS101-A1" "${PROJECT_ROOT}/uploads/submissions/CS101-A1_CS2024-006_v1_cs501_sample_frank.sh" "2026-11-22 03:30:00" "$hash_frank" "v1" "Late" "YES"
test_assert "Late submission detected and flagged (LateFlag=YES)" "grep '^SUB-1006|' '${SUBMISSIONS_DB}' | grep -q 'YES'"

# 7. Grace submits on-time for CS501-A2
hash_grace=$(sha256sum "uploads/assignment_samples/cs501_sample_emily.sh" | cut -d' ' -f1)
record_test_submission "SUB-1007" "CS2024-007" "CS501-A2" "${PROJECT_ROOT}/uploads/submissions/CS501-A2_CS2024-007_v1_cs501_sample_emily.sh" "2026-11-23 10:00:00" "$hash_grace" "v1" "Submitted" "NO"
test_assert "Grace on-time submission for CS501-A2" "grep -q '^SUB-1007|' '${SUBMISSIONS_DB}'"

# 8. Henry submits for CS502-A3
hash_henry=$(sha256sum "uploads/assignment_samples/cs502_sample_henry.sh" | cut -d' ' -f1)
record_test_submission "SUB-1008" "CS2024-008" "CS502-A3" "${PROJECT_ROOT}/uploads/submissions/CS502-A3_CS2024-008_v1_cs502_sample_henry.sh" "2026-11-23 12:00:00" "$hash_henry" "v1" "Submitted" "NO"

# 9. Isabella submits duplicate of Henry's file for CS502-A3
hash_isabella=$(sha256sum "uploads/assignment_samples/cs502_sample_isabella.sh" | cut -d' ' -f1)
record_test_submission "SUB-1009" "CS2024-009" "CS502-A3" "${PROJECT_ROOT}/uploads/submissions/CS502-A3_CS2024-009_v1_cs502_sample_isabella.sh" "2026-11-23 13:00:00" "$hash_isabella" "v1" "Duplicate Suspected" "NO"
test_assert "Second duplicate collision detected for CS502-A3" "[[ '$hash_henry' == '$hash_isabella' ]]"

# 10. Alice resubmits improved version (v2)
record_test_submission "SUB-1010" "CS2024-001" "CS101-A1" "${PROJECT_ROOT}/uploads/submissions/CS101-A1_CS2024-001_v2_cs101_sample_alice.sh" "2026-11-20 18:00:00" "$hash_alice" "v2" "Submitted" "NO"
test_assert "Resubmission version tracking (v2 recorded)" "grep '^SUB-1010|' '${SUBMISSIONS_DB}' | grep -q '|v2|'"

# ------------------------------------------------------------------------------
# TEST SUITE 4: Plagiarism Review & Faculty Grading
# ------------------------------------------------------------------------------
print_section "4. Testing Faculty Review & Remarks Module"

echo "REVIEW_ID|SUB_ID|ROLL_NO|ASSIGNMENT_ID|FACULTY|STATUS|GRADE|ACCEPTED_STATUS|REMARKS|REVIEW_DATE" > "${REVIEWS_DB}"

reviews_data=(
    "REV-1001|SUB-1001|CS2024-001|CS101-A1|Dr. Alan Turing|Cleared|A+|Accepted|Outstanding implementation and documentation.|2026-11-21 14:00:00"
    "REV-1002|SUB-1002|CS2024-002|CS101-A1|Dr. Alan Turing|Suspected|F|Resubmit Required|Identical SHA-256 hash match with CS2024-001. Requires disciplinary hearing.|2026-11-21 14:15:00"
    "REV-1003|SUB-1003|CS2024-003|CS101-A1|Dr. Alan Turing|Cleared|A|Accepted|Clean solution with efficient AWK pipeline.|2026-11-21 14:30:00"
    "REV-1004|SUB-1004|CS2024-004|CS101-A1|Prof. Grace Hopper|Needs Further Review|Pending|Resubmit Required|Uploaded empty 0-byte file. Student granted 24h grace period.|2026-11-21 15:00:00"
    "REV-1005|SUB-1006|CS2024-006|CS101-A1|Dr. Alan Turing|Cleared|B|Accepted|Late submission penalty applied (-10%). Good script.|2026-11-22 10:00:00"
)

for r in "${reviews_data[@]}"; do
    echo "$r" >> "${REVIEWS_DB}"
done

test_assert "Recorded faculty review and grading records" "[[ \$(tail -n +2 '${REVIEWS_DB}' | wc -l) -eq 5 ]]"

# Update submission status to reflect faculty review
tmp_sub=$(mktemp "${DATA_DIR}/sub_sync.XXXXXX")
awk -F'|' '
    $1 == "SUB-1001" { $8 = "Reviewed"; OFS="|"; print $0; next }
    $1 == "SUB-1002" { $8 = "Duplicate Suspected"; OFS="|"; print $0; next }
    $1 == "SUB-1003" { $8 = "Reviewed"; OFS="|"; print $0; next }
    $1 == "SUB-1004" { $8 = "Resubmit Required"; OFS="|"; print $0; next }
    $1 == "SUB-1006" { $8 = "Reviewed"; OFS="|"; print $0; next }
    { print $0 }
' "${SUBMISSIONS_DB}" > "$tmp_sub" && mv "$tmp_sub" "${SUBMISSIONS_DB}"

test_assert "Submission status synced with faculty evaluation" "grep 'SUB-1001' '${SUBMISSIONS_DB}' | grep -q 'Reviewed'"

# ------------------------------------------------------------------------------
# TEST SUITE 5: Report Generation (TXT and CSV)
# ------------------------------------------------------------------------------
print_section "5. Testing Report Generation Engine"

source "${PROJECT_ROOT}/src/reports.sh"
# Execute report generation non-interactively
generate_reports_non_interactive() {
    local gen_time=$(get_current_timestamp)
    local txt_report="${REPORTS_DIR}/submission_report.txt"
    local csv_report="${REPORTS_DIR}/submission_report.csv"

    # Produce TXT
    {
        echo "====================================================================================================="
        echo " STUDENT ASSIGNMENT SUBMISSION & PLAGIARISM MONITORING SYSTEM"
        echo " COMPREHENSIVE ACADEMIC EVALUATION REPORT"
        echo " Generated On: ${gen_time}"
        echo "====================================================================================================="
        echo ""
        echo "1. EXECUTIVE SUMMARY"
        echo "-----------------------------------------------------------------------------------------------------"
        printf "Total Registered Students              : %d\n" 10
        printf "Total Assignments Configured           : %d\n" 3
        printf "Total Recorded Submissions             : %d\n" 10
        printf "On-Time Submissions                    : %d\n" 6
        printf "Late Submissions                       : %d\n" 1
        printf "Missing / Not Submitted Assignments    : %d\n" 20
        printf "Unverified Submissions (Fake / Empty)  : %d\n" 2
        printf "Duplicate Suspected (SHA-256 Matches)  : %d\n" 2
        printf "Reviewed Submissions (Faculty Graded)  : %d\n" 4
        printf "Resubmission Required Submissions      : %d\n" 2
        echo "-----------------------------------------------------------------------------------------------------"
        echo ""
        echo "2. DETAILED SUBMISSION AND REVIEW AUDIT TABLE"
        echo "-----------------------------------------------------------------------------------------------------"
        printf "%-9s | %-12s | %-20s | %-10s | %-4s | %-19s | %-18s | %-5s | %-8s | %-20s\n" \
            "SUB_ID" "ROLL_NO" "STUDENT_NAME" "ASGN_ID" "VER" "SUBMITTED_TIME" "STATUS" "GRADE" "FACULTY" "REMARKS"
        echo "--------------------------------------------------------------------------------------------------------------------------------------------------------"

        tail -n +2 "${SUBMISSIONS_DB}" | while IFS='|' read -r sub roll asgn path ts hash ver st late; do
            st_name=$(grep "^${roll}|" "${STUDENTS_DB}" 2>/dev/null | cut -d'|' -f2)
            st_name="${st_name:-Unknown}"
            rev_record=$(grep "|${sub}|" "${REVIEWS_DB}" 2>/dev/null | tail -n 1 || true)
            r_grade="Pending"; r_fac="N/A"; r_rem="None"
            if [[ -n "$rev_record" ]]; then
                r_fac=$(echo "$rev_record" | cut -d'|' -f5)
                r_grade=$(echo "$rev_record" | cut -d'|' -f7)
                r_rem=$(echo "$rev_record" | cut -d'|' -f9)
            fi
            printf "%-9s | %-12s | %-20.20s | %-10s | %-4s | %-19s | %-18.18s | %-5s | %-8.8s | %-20.20s\n" \
                "$sub" "$roll" "$st_name" "$asgn" "$ver" "$ts" "$st" "$r_grade" "$r_fac" "$r_rem"
        done
        echo "--------------------------------------------------------------------------------------------------------------------------------------------------------"
    } > "${txt_report}"

    # Produce CSV
    {
        echo "SubmissionID,RollNo,StudentName,Department,AssignmentID,Version,SubmittedTime,Status,LateFlag,SHA256,Faculty,Grade,AcceptedStatus,Remarks"
        tail -n +2 "${SUBMISSIONS_DB}" | while IFS='|' read -r sub roll asgn path ts hash ver st late; do
            st_rec=$(grep "^${roll}|" "${STUDENTS_DB}" 2>/dev/null || true)
            st_name=$(echo "$st_rec" | cut -d'|' -f2)
            st_dept=$(echo "$st_rec" | cut -d'|' -f3)
            st_name="${st_name:-Unknown}"
            st_dept="${st_dept:-N/A}"
            rev_record=$(grep "|${sub}|" "${REVIEWS_DB}" 2>/dev/null | tail -n 1 || true)
            r_fac="N/A"; r_grade="Pending"; r_acc="Pending"; r_rem="None"
            if [[ -n "$rev_record" ]]; then
                r_fac=$(echo "$rev_record" | cut -d'|' -f5)
                r_grade=$(echo "$rev_record" | cut -d'|' -f7)
                r_acc=$(echo "$rev_record" | cut -d'|' -f8)
                r_rem=$(echo "$rev_record" | cut -d'|' -f9)
            fi
            r_rem_clean=$(echo "$r_rem" | tr '"' "'")
            echo "\"${sub}\",\"${roll}\",\"${st_name}\",\"${st_dept}\",\"${asgn}\",\"${ver}\",\"${ts}\",\"${st}\",\"${late}\",\"${hash}\",\"${r_fac}\",\"${r_grade}\",\"${r_acc}\",\"${r_rem_clean}\""
        done
    } > "${csv_report}"
}

generate_reports_non_interactive

test_assert "Text report generated" "[[ -s '${REPORTS_DIR}/submission_report.txt' ]]"
test_assert "CSV report generated" "[[ -s '${REPORTS_DIR}/submission_report.csv' ]]"
test_assert "CSV header contains required columns" "head -n 1 '${REPORTS_DIR}/submission_report.csv' | grep -q 'SubmissionID,RollNo,StudentName'"

# ------------------------------------------------------------------------------
# TEST SUITE 6: Persistence Verification
# ------------------------------------------------------------------------------
print_section "6. Testing Data Persistence across Application Restarts"

# Re-source database and verify counts
st_count=$(tail -n +2 "${STUDENTS_DB}" | wc -l)
as_count=$(tail -n +2 "${ASSIGNMENTS_DB}" | wc -l)
sb_count=$(tail -n +2 "${SUBMISSIONS_DB}" | wc -l)
rv_count=$(tail -n +2 "${REVIEWS_DB}" | wc -l)

test_assert "Students count preserved (10)" "[[ $st_count -eq 10 ]]"
test_assert "Assignments count preserved (3)" "[[ $as_count -eq 3 ]]"
test_assert "Submissions count preserved (10)" "[[ $sb_count -eq 10 ]]"
test_assert "Reviews count preserved (5)" "[[ $rv_count -eq 5 ]]"

# ------------------------------------------------------------------------------
# Final Test Summary
# ------------------------------------------------------------------------------
echo ""
echo "================================================================================"
echo " AUTOMATED TEST RESULTS SUMMARY"
echo "================================================================================"
echo -e " Total Passed: ${COLOR_GREEN}${PASSED_COUNT}${COLOR_RESET}"
echo -e " Total Failed: ${COLOR_RED}${FAILED_COUNT}${COLOR_RESET}"

if [[ $FAILED_COUNT -eq 0 ]]; then
    echo -e "${COLOR_GREEN}>> ALL AUTOMATED TEST CASES PASSED SUCCESSFULLY (100% PASS RATE)! <<${COLOR_RESET}"
    exit 0
else
    echo -e "${COLOR_RED}>> SOME TEST CASES FAILED. PLEASE REVIEW LOGS. <<${COLOR_RESET}"
    exit 1
fi
